package com.mangox.newsletterx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsletterxApplicationTests {

	@Test
	void contextLoads() {
	}

}
