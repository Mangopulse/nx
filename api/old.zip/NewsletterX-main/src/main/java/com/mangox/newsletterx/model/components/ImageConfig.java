package com.mangox.newsletterx.model.components;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ImageConfig {
    Integer width;
    Integer height;
}
