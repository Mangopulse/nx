package com.mangox.newsletterx.model.enums;

public enum TokenType {
    BEARER
}
