package com.mangox.newsletterx.exception;

public class ErrorException extends Exception{
    public ErrorException(String message) {
        super(message);
    }
}
