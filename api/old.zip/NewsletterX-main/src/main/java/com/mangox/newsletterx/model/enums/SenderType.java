package com.mangox.newsletterx.model.enums;

public enum SenderType {
    UNDEFINED,
    SENDGRID,
    MAILCHIMP,
    SMTP
}
