package com.mangox.newsletterx.model.enums;

public enum HtmlComponentType {
    HEADING_ROW, COVER, BASIC_WIDGET, FOOTER
}

