package com.mangox.newsletterx.model.enums;

public enum EnvVariables {
    LINK,SENDGRID_API_KEY
}
