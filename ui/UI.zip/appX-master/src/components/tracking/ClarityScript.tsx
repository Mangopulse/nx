"use client"
import Script from "next/script";
import * as React from "react";

export interface IClarityScriptProps {}

export default function ClarityScript(props: IClarityScriptProps) {
    return (
        <>

            <Script strategy="lazyOnload" id="clarity-script" type="text/javascript">
                {`
                    (function(c,l,a,r,i,t,y){
                        c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
                        t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
                        y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
                    })(window, document, "clarity", "script", "km6ev59mll");
                `}
            </Script>
        </>
    );
}
